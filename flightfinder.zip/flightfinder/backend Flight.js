const mongoose = require('mongoose');

const flightSchema = new mongoose.Schema({
  airline: String,
  from: String,
  to: String,
  departureTime: String, // departure time as a string (e.g. "10:30 AM")
  arrivalTime: String,
  price: Number
});

module.exports = mongoose.model('Flight', flightSchema);


