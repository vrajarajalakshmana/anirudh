fetch('http://localhost:5500/api/flights')
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById('flights');
    data.forEach(flight => {
      const div = document.createElement('div');
      div.className = "flight-card";
      div.innerHTML = `
        <h3>${flight.airline}</h3>
        <p>${flight.from} → ${flight.to}</p>
        <p>Depart: ${flight.departureTime}</p>
        <p>Arrive: ${flight.arrivalTime}</p>
        <p>Price: $${flight.price}</p>
        <hr />
      `;
      container.appendChild(div);
    });
  });
