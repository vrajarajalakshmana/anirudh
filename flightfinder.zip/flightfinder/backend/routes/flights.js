const express = require('express');
const router = express.Router();


// GET all flights
router.get('/', async (req, res) => {
  const flights = await Flight.find();
  res.json(flights);
});

// POST new flight
router.post('/', async (req, res) => {
  try {
    const newFlight = new Flight(req.body);
    await newFlight.save();
    res.status(201).send('Flight added');
  } catch (err) {
    res.status(400).send(err.message);
  }
});

module.exports = router;
