const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

// Create Express app
const app = express();
const port = 8080; // Running on localhost:8080

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB (local)
mongoose.connect('mongodb://localhost:27017/flightfinder', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ Connected to MongoDB at mongodb://localhost:27017/flightfinder'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// Flight Schema & Model
const flightSchema = new mongoose.Schema({
  airline: String,
  flightNumber: String,
  departure: String,
  arrival: String,
  departureTime: Date,
  arrivalTime: Date,
  price: Number
});

const Flight = mongoose.model('Flight', flightSchema);

// Routes

// GET all flights
app.get('/api/flights', async (req, res) => {
  try {
    const flights = await Flight.find();
    res.json(flights);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST a new flight
app.post('/api/flights', async (req, res) => {
  const flight = new Flight(req.body);
  try {
    const savedFlight = await flight.save();
    res.status(201).json(savedFlight);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
